#!/usr/bin/env bash
# This script was NOT executed successfully in the preparation environment.
# Requirements: git, a working elan/lake installation, and network access.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
for executable in git lake; do
  if ! command -v "$executable" >/dev/null 2>&1; then
    printf 'Missing prerequisite: %s\n' "$executable" >&2
    exit 2
  fi
done
revision=29ea5de9cb981cb62dfa7979aaff0851f50c603a
tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
git -C "$tmp" init --quiet
git -C "$tmp" fetch --quiet --depth=1 \
  https://github.com/leanprover-community/mathlib4.git "$revision"
# Obtain the exact dependency toolchain instead of guessing its Lean version.
git -C "$tmp" show FETCH_HEAD:lean-toolchain > lean-toolchain
lake update
lake exe cache get
./check_lean.sh
