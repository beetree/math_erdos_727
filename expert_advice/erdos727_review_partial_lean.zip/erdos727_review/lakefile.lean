import Lake
open Lake DSL

package erdos727_review where
  version := v!"0.1.0"

-- API documentation examined at this revision; project not compiler-tested.
-- setup_and_check.sh obtains the matching lean-toolchain from this revision.
require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @
  "29ea5de9cb981cb62dfa7979aaff0851f50c603a"

@[default_target]
lean_lib Erdos727
