from collections import Counter
from fractions import Fraction as R
from math import gcd


# (a_i, b_i, j_i, alpha_i, beta_i, derivative at root)
DATA = [
    (35, 36, 1, R(6, 35), R(-41, 35), -41),
    (6, 5, 1, R(35, 6), R(41, 6), 41),
    (1, 1, 2, R(210), R(-29), -29),
    (210, 181, 2, R(1, 210), R(29, 210), 29),
    (15, 14, 3, R(14, 15), R(-1, 15), -1),
    (14, 13, 3, R(15, 14), R(1, 14), 1),
]


def check_algebra_and_residues():
    bad_proportions = []
    for a, b, j, alpha, beta, derivative in DATA:
        assert gcd(a, b) == 1
        assert alpha*a*a == 210
        assert 2*alpha*a*b + beta*a == 391
        assert alpha*b*b + beta*b - j == 179
        assert 420*R(-b, a) + 391 == derivative
        d = alpha.denominator
        if d == 1:
            assert beta < 0
            bad_proportions.append(R(0))
            continue
        assert a % d == 0 and gcd(b, d) == 1
        counts = Counter()
        for m in range(d):
            if gcd(m, d) == 1:
                counts[(alpha*m*m) % 1] += 1
        assert len(set(counts.values())) == 1
        assert R(0) not in counts and R(1, 2) not in counts
        bad = sum(count for x, count in counts.items() if x < R(1, 2))
        bad_proportions.append(R(bad, sum(counts.values())))
    assert bad_proportions == [R(1, 6), R(0), R(0), R(1, 3), R(0), R(1, 3)]
    assert sum(bad_proportions) == R(5, 6)


def factor(n):
    out = {}
    p = 2
    while p*p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p = 3 if p == 2 else p + 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def carries(n, p):
    total, q = 0, p
    while q <= 2*n:
        total += (2*n)//q - 2*(n//q)
        q *= p
    return total


def check_parameter(t):
    assert t >= 1
    n = 210*t*t + 391*t + 179
    factors = [a*t+b for a, b, *_ in DATA]
    for j in range(1, 4):
        assert factors[2*j-2]*factors[2*j-1] == n+j
    valuations = {}
    for value in factors:
        for p, exponent in factor(value).items():
            valuations[p] = valuations.get(p, 0) + exponent
    rows = [(p, carries(n, p), 2*exponent)
            for p, exponent in sorted(valuations.items())]
    return n, all(actual >= needed for p, actual, needed in rows), rows


if __name__ == '__main__':
    check_algebra_and_residues()
    print(check_parameter(61))
    print(sum(check_parameter(t)[1] for t in range(1, 10001)))
