#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if ! command -v lake >/dev/null 2>&1; then
  echo 'Lean/Lake is unavailable: no Lean verification was performed.' >&2
  exit 2
fi
if [[ ! -f lean-toolchain ]]; then
  echo 'Matching toolchain not resolved. Run setup_and_check.sh first.' >&2
  exit 2
fi
mkdir -p logs
lake build 2>&1 | tee logs/lean_build.log
lake env lean AuditAxioms.lean 2>&1 | tee logs/lean_axioms.log
if grep -Eq 'sorryAx|declaration uses .sorry.' logs/lean_build.log logs/lean_axioms.log; then
  echo 'A placeholder dependency was detected. Inspect the logs.' >&2
  exit 1
fi
printf '%s\n' \
  'The draft built and its selected axiom reports were produced.' \
  'This DOES NOT prove K3: RequiredEstimates is still an explicit, uninstantiated hypothesis.'
