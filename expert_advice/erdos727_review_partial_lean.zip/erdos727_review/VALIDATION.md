# Review of the candidate k = 3 proof of Erdős Problem 727

**Review date:** 6 September 2026.  
**Source reviewed:** `erdos_727_k2_k3_proof(2).md`, 836 lines; the earlier `(1)` upload has identical contents.  
**Mathematical assessment:** I found no fatal mathematical gap in the supplied argument. The argument appears sound with its stated, classical, unconditional fixed-modulus prime-number-theorem input. This is an informal mathematical review, not independent expert certification or a Lean kernel certificate.  
**Formalization assessment:** The accompanying Lean development is **partial and uncompiled**. In particular, the analytic exceptional-set estimates have not been formalized, and the project does not prove the unconditional infinitude theorem.

## 1. Precisely what the argument claims

The primary claim is that, with

\[
f(t)=210t^2+391t+179,
\]

there are fixed integers \(Q\ge1\), \(0\le t_0<Q\), and \(X_0\) such that at least \(X/100\) integers \(v\in[X,2X)\) satisfy

\[
((f(t_0+Qv)+3)!)^2\mid (2f(t_0+Qv))!
\]

for every integer \(X\ge X_0\). Infinitely many distinct positive values of \(n\), a lower bound of order \(\sqrt Z\) up to \(Z\), and the \(k=2\) corollary follow. The source does not claim the general case for all fixed \(k\).

This review follows the manuscript's organization. References such as “§9, (9.4)” refer to the uploaded manuscript. Additional finite calculations introduced in this review are identified explicitly.

## 2. Factorial divisibility and carries: valid

The cancellation in §2 is an equivalence, not just a sufficient condition. With

\[
A(n)=(n+1)(n+2)(n+3),\qquad B(n)=\binom{2n}{n},
\]

one has

\[
(n+3)!=n!A(n),\qquad (2n)!=(n!)^2B(n),
\]

and the common positive factor \((n!)^2\) can be cancelled in the divisibility statement. The desired condition is therefore

\[
A(n)^2\mid B(n).
\]

Legendre's formula gives the primewise criterion

\[
2v_p(A(n))\le c_p(n),\qquad
c_p(n)=\sum_{h\ge1}\mathbf1_{\,2(n\bmod p^h)\ge p^h}.
\]

The sum is finite: a carry implies \(p^h\le2n\). The inequality includes equality at a half, which matters at the binary prime. There is no need to check a prime not dividing \(A(n)\).

The accompanying Lean draft uses mathlib's existing Kummer theorem, `Nat.factorization_choose'`, rather than attempting to evaluate a large binomial coefficient or asserting a new carry axiom.

## 3. Six linear factors: valid; exact computations agree

The three polynomial identities in §3 expand correctly. The six affine-coordinate identities in §11 and all six derivative constants agree exactly with rational arithmetic.

There is a useful stronger identity, independently checked in this review:

\[
420t+391-c_i=\frac{420}{a_i}L_i(t),
\]

where the integer multipliers, in source order, are \(12,70,420,2,28,30\). Consequently the derivative congruence follows without any ambiguity about rational substitution.

The forms are primitive. Their slope primes are among \(2,3,5,7\). The within-pair determinants are \(-41,-29,-1\). If a prime divides forms from two different pairs, it divides the difference of the corresponding members of \(f+1,f+2,f+3\), hence divides 1 or 2. This establishes the claimed disjointness for primes above 1000. As a separate exact audit, I computed all 15 pairwise determinants; all their prime factors are at most 41.

## 4. The fixed small-prime progression: valid

At \(t=0\), the relevant product is \(180\cdot181\cdot182\), with support

\[
S=\{2,3,5,7,13,181\}.
\]

The individual valuations of \(180,181,182\) are:

| Prime | Individual valuations | Sum \(e_p\) | \(b_p\) |
|---:|---:|---:|---:|
| 2 | 2, 0, 1 | 3 | 3 |
| 3 | 2, 0, 0 | 2 | 3 |
| 5 | 1, 0, 0 | 1 | 2 |
| 7 | 0, 0, 1 | 1 | 2 |
| 13 | 0, 0, 1 | 1 | 2 |
| 181 | 0, 1, 0 | 1 | 2 |

Thus each \(b_p\) is strictly larger than every individual valuation it must preserve. The target in (4.1) agrees with 179 modulo \(p^{b_p}\). The derivative at the initial branch is \(391=17\cdot23\), which is a unit at every prime in \(S\). The digit-by-digit lift is therefore justified.

The prescribed run of \(2e_p\) digits \(p-1\) really does supply \(2e_p\) carries, including for \(p=2\). Each such digit creates a carry independently of whether one arrives from the previous digit.

**Additional exact computation in this review:** I constructed the local lifts and the CRT representative. The least local roots are:

| Prime | Modulus | Target residue of \(f(t)\) | Root residue of \(t\) |
|---:|---:|---:|---:|
| 2 | 512 | 507 | 248 |
| 3 | 2187 | 2177 | 1107 |
| 5 | 625 | 604 | 300 |
| 7 | 2401 | 2384 | 196 |
| 13 | 28561 | 28402 | 17238 |
| 181 | 1073283121 | 1073250539 | 491349478 |

The resulting \(Q\) has 436 decimal digits. Its full value and the corresponding \(t_0\) are in `checks_output.json` and `SmallPrimeCertificates.lean`. The audit checks every CRT congruence, as well as small-prime valuation/carry conditions at parameters \(v=0,1,2,17,1000\). Those sample parameters are finite checks, not substitutes for the general progression argument.

An enormous \(Q\) is not a mathematical objection: it is fixed before \(X\) tends to infinity. The proof gives no practically small threshold \(X_0\).

## 5. Repeated factors and reduction to one extra carry: valid

For \(p>1000\), the slope \(a_iQ\) is invertible modulo \(p^2\). Thus \(p^2\mid\mathcal L_i(v)\) picks out one residue class. A parameter in \([X,2X)\) with this property must have \(p\le\sqrt{CX}\), since the positive linear form is at most \(CX\).

The union bound is therefore

\[
6X\sum_{p>1000}p^{-2}+6\pi(\sqrt{CX})
\le 0.006X+o(X).
\]

After these exclusions, a large prime dividing the product has exponent exactly one: disjointness of the six factors is essential here. The congruence \(F(v)\equiv-j_i\pmod p\), with \(1\le j_i\le3\) and \(p>6\), supplies the first carry. Failure then requires the absence of every carry at levels \(h\ge2\). The source's event (5.2) is the correct necessary failure event.

## 6. Prime harmonic sums: valid with the stated external input

The manuscript's only external analytic input is a prime number theorem in arithmetic progressions for fixed modulus. NIST DLMF equation 27.12.8 gives an error term stronger than needed for any fixed modulus; the cited ordinary-prime counterpart is equation 27.12.5. These are unconditional results.

Partial summation of the stated exponential error gives a convergent error integral, yielding

\[
\sum_{p\le z,\ p\equiv a\ (d)}\frac1p
=\frac{\log\log z}{\varphi(d)}+B_{d,a}+o(1).
\]

Subtracting at power-scale endpoints proves (6.3) and (6.4). The factor \(C\) in an endpoint \(CX^b\) affects \(\log\log(CX^b)\) only by \(o(1)\), provided \(C\) is fixed.

The weighted limit in (6.5) needs special care near the lower endpoint. The manuscript supplies that care: split at a fixed \(Z\), let \(X\to\infty\) first, and then let \(Z\to\infty\). The small fixed-prime part vanishes, while the remainder is controlled by the tail supremum of the Mertens remainder. This is sufficient; a prime-by-prime limiting argument without the tail estimate would not be sufficient.

## 7. Very small primes: valid, including the incoming carry

For \(1000<p\le X^{1/20}\), the chosen depth

\[
\ell=\left\lfloor\frac{\log X}{2\log p}\right\rfloor
\]

satisfies \(\ell\ge10\) and \(p^\ell\le\sqrt X\). The nonsingular branch of \(F\) is bijective onto the corresponding branch of values modulo \(p^\ell\).

Since the units digit already gives a carry, the next digit has \((p-1)/2\) allowable choices. Once that carry is extinguished, subsequent digits have \((p+1)/2\) choices. Hence the count

\[
\frac{p-1}{2}\left(\frac{p+1}{2}\right)^{\ell-2}
\]

is correct. Treating all digits as independent half-events would miss this distinction.

The endpoint contribution is \(O(\sqrt X\log\log X)=o(X)\). The weighted harmonic limit then controls the main term. The elementary inequalities used to conclude

\[
6\rho^{-2}E_1(c/\delta)<4e^{-6}<0.01
\]

are valid. The exact rational checks in `checks.py` include the stated exponential-series certificates and the rational logarithm lower bound; no numerical integration is used to justify this bound.

## 8. Uniform quadratic exponential sums: valid

The Gauss-sum calculation works for every odd \(q\), not only prime \(q\). The invertibility of \(2a\) modulo \(q\) makes all off-diagonal terms vanish after summing over the second variable, leaving \(|G_b|^2=q\).

For an interval of length at most \(q\), Fourier inversion reduces the estimate to a shifted grid of geometric sums. A shifted grid has only a bounded number of points in each distance shell of width \(1/q\) from the integers. The closest points contribute \(O(q)\), and the remaining shells contribute \(O(q\log q)\). This argument is uniform in the arbitrary real linear coefficient \(\theta\).

Subdividing longer intervals proves (8.1). Translating a block changes only a constant phase and the linear coefficient, so arbitrary block locations introduce no unaddressed dependence.

## 9. Medium-prime uniform distribution: valid; the central analytic step

This is the most important point in the review. Pointwise equidistribution separately for each fixed prime would not justify the sum over growing primes. The source proves an appropriate uniform statement instead.

On a conditioned root class, write \(v=v_0+pz\); the interval length is \(L=X/p+O(1)\). For a fixed nonzero integer Fourier frequency, let \(H\) be the largest occupied coordinate.

For \(H\ge3\), the leading coefficient has denominator exactly \(p^{H-2}\), once the finitely many prime divisors of the fixed numerator have been passed. The quadratic-sum estimate gives normalized size

\[
O\!\left(\left(p^{-(H-2)/2}+\frac{p^{H/2}}X\right)\log X\right).
\]

On the band

\[
X^{2/(J+1)+\eta}<p\le X^{2/J-\eta},
\]

the first term decays because \(p\ge X^{1/20}\), and the second is at most a constant times \(X^{-\eta J/2}\log X\). Both bounds are uniform over the primes and conditioned intervals in the band.

For \(H=2\), the quadratic coefficient is integral. The remaining linear coefficient modulo one is \(h_2Qc_i/p\), whose numerator is fixed and nonzero. The normalized geometric-sum estimate is \(O(p^2/X)=o(1)\) uniformly below \(X^{1/2-\eta}\).

It is legitimate to pass from these estimates to the box indicator. For a fixed approximation accuracy, choose a finite trigonometric approximation first. There are then only finitely many frequencies and therefore one common sufficiently large threshold. Take \(X\to\infty\) before refining the approximation. The fixed dimension is at most 38. The fact that the coordinates arise from the same number and depend on \(p\) does not invalidate this Fourier argument.

The resulting uniform discrepancy can be summed: if it is at most \(\epsilon_X\to0\), its total main-term error is bounded by

\[
X\epsilon_X\sum_{p\text{ in the band}}\frac1p=o(X).
\]

The endpoint errors also sum to \(o(X)\). Thus (9.7), including its conservative bound \(3/8\), is justified. No probabilistic independence is required.

## 10. Boundary strips: valid

The 37 strips cover the missing prime exponents between \(1/20\) and \(1/2+\eta\). The minimum unmargined gap between consecutive band exponents is \(1/780>2\eta\), so the medium intervals are nonempty.

The sum of indices is \(\sum_{j=4}^{40}j=814\), and the displayed rational estimate gives

\[
6\sum_{j=4}^{40}\log\frac{2/j+\eta}{2/j-\eta}
\le\frac{6\eta\cdot814}{1-20\eta}<0.004885<0.01.
\]

Counting all divisibility events is an upper bound even when ranges overlap. Since all primes in these strips are at most \(X^{1/2+\eta}\), the accumulated endpoint error is \(o(X)\).

## 11. Large primes: valid, including the special third factor

The identity

\[
\frac{f(t)}{p^2}=\alpha_i m^2+\beta_i\frac mp-\frac{j_i}{p^2}
\]

is exact when \(L_i(t)=pm\). For \(p>X^{1/2+\eta}\), the correction tends to zero uniformly because \(m/p\le CX/p^2\).

For \(i\ne3\), the denominator divides the original slope and is coprime to the intercept. Thus \(m\equiv b_ip^{-1}\pmod{d_i}\). Multiplication by \(b_i\) followed by inversion is a permutation of the unit group. Restriction to the enormous progression modulo \(Q\) does not change this identity and does not require a prime theorem uniform in \(Q\).

The residue images and their multiplicities reproduce the source table. As an additional check, the **bad prime classes**, rather than just the bad classes of \(m\), are:

| Source factor | Modulus | Bad prime classes | Fraction |
|---:|---:|---|---:|
| 1 | 35 | 1, 6, 29, 34 | 4/24 = 1/6 |
| 2 | 6 | none | 0 |
| 3 | 1 | special negative-correction argument | 0 |
| 4 | 210 | 1, 23, 29, 37, 41, 47, 71, 103, 107, 139, 163, 169, 173, 181, 187, 209 | 16/48 = 1/3 |
| 5 | 15 | none | 0 |
| 6 | 14 | 1, 13 | 2/6 = 1/3 |

The sum is \(5/6\).

One detail worth making explicit in a formal proof is that stability of fractional parts must exclude wraparound at an integer as well as crossing \(1/2\). The source's finite tables avoid both boundaries. Their denominators are at most 210; a sufficiently small common correction, for example less than \(1/1000\) in absolute value, preserves every relevant classification. This is an expansion of the source's existing finite-distance argument, not a repair of a false estimate.

For the third factor, \(\alpha_3m^2\) is integral, so the preceding table argument must NOT be used. Its correction is strictly negative and eventually lies in \((-1/2,0)\), placing the fractional part in \((1/2,1)\). The source handles this correctly.

The fixed-modulus prime harmonic asymptotics then give

\[
\limsup E_{\rm large}(X)/X
\le\frac56\log\frac1{1/2+\eta}<\frac7{12}.
\]

The endpoint error \(O(\pi(CX))\) is indeed \(o(X)\) for a fixed, even enormous, \(C\). No uniform estimate over varying \(C\) is being asserted.

## 12. Completion: valid

The five conservative failure budgets are:

| Exceptional parameters | Budget |
|---|---:|
| Repeated prime factors above 1000 | 3/500 |
| Very small primes | 1/100 |
| Medium bands | 3/8 |
| Boundary strips | 1/100 |
| Large primes | 7/12 |
| Total | 2953/3000 |

The arithmetic is exact:

\[
\frac{2953}{3000}<\frac{99}{100},\qquad
\frac{99}{100}-\frac{2953}{3000}=\frac{17}{3000}.
\]

There are finitely many forms, bands, and approximations at each fixed accuracy, and all structural constants were fixed before the limit. Thus one can combine the estimates into a single eventual bound. For example, giving each of the five errors an allowance of \(1/1000\) yields total failure at most \((371/375)X\), still less than \(0.99X\). The Lean counting draft uses exactly this explicit allowance rather than informal manipulation of `limsup`.

The polynomial is strictly increasing on nonnegative integers, and \(F(v)\ge v\) when \(Q\ge1\). Thus successful parameters in arbitrarily large blocks give unbounded successful values of \(n\). The separate quadratic growth bound gives the source's \(\sqrt Z\) counting consequence. The factor \((n+3)^2\) gives the \(k=2\) corollary immediately.

## 13. Finite computational audit actually executed

Both the attachment's own Python code and an independently written standard-library audit were executed. They agree on:

- the complete example \(t=61\), \(n=805440\), and all eleven valuation rows;
- the count of 1612 successful parameters among \(1\le t\le10000\);
- the algebraic identities, derivative constants, residue proportions, and numerical rational bounds.

The independent audit also verifies every pairwise resultant, enumerates the bad prime classes, performs the Hensel lifting, and constructs the exact CRT representative. For the example, the independently computed carry counts are

\[
6,9,5,2,3,5,2,2,2,2,2
\]

for primes

\[
2,3,7,11,13,17,31,53,167,929,1181.
\]

The required counts are 2 except at 17, where the required count is 4. The audit checks carries by remainder comparisons and cross-checks them using factorial valuations. This avoids relying solely on the source implementation's quotient-difference loop.

These finite calculations do not prove infinitude and do not certify any Lean source.

## 14. What the Lean package does and does not supply

The source files contain proof drafts for the algebraic reduction, a specialization of mathlib's Kummer theorem, finite residue computations, explicit local CRT certificates, the numerical example, and the final counting-to-infinitude implication.

The actual exceptional sets are defined in `Obligations.lean`. The proposition `RequiredEstimates Q t₀` records coverage and all five required asymptotic estimates. **No term of that proposition is constructed.** The final implication

`RequiredEstimates Q t₀ → K3`

is not an unconditional proof of `K3`, regardless of whether the file contains textual proof placeholders. In addition, no Lean compiler was available, and attempts to obtain one were unsuccessful. The supplied source has not been elaborated, compiled, or checked for axiom dependencies; syntax or API repairs may be needed.

The missing Lean work is substantial and specific: progression safety and complete failure coverage; square-divisor counting; the prime harmonic asymptotics including the weighted lower endpoint; uniform quadratic-sum bounds; uniform approximation of box indicators; and the summation of uniform errors for the actual prime bands and residue classes. The stronger counting consequence in \(Z\) is also not formalized in the supplied draft.

## References checked outside the attachment

1. NIST Digital Library of Mathematical Functions, §27.12, especially equations 27.12.5 and 27.12.8. This verifies the classical analytic input stated in the manuscript.
2. mathlib documentation, `Mathlib.Data.Nat.Choose.Factorization`: `Nat.factorization_factorial` and `Nat.factorization_choose'` provide Legendre and Kummer formulations.
3. mathlib documentation, `Mathlib.Data.Nat.Factorization.Basic` and `.Defs`: divisibility through prime factorizations, and product/power identities.
4. The public Formal Conjectures entry `FormalConjectures/ErdosProblems/727.lean` was used to cross-check the general statement. Its theorem bodies retrieved in this review contain placeholders; it is not an existing proof to import.

The Erdős Problems page itself returned an access error during this review. Its substantive statement was therefore cross-checked against the public formal-conjecture file and the supplied attachment, not claimed to have been read through that blocked page.

**Bottom line:** This review supports the mathematical argument as written. It does not establish that the accompanying partial Lean development compiles, and it does not complete the requested full Lean formalization.
