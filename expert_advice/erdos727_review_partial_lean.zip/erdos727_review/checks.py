#!/usr/bin/env python3
"""Independent exact finite audit of the uploaded Erdos 727 manuscript.

This checks arithmetic and finite certificates. It does not prove asymptotic
estimates or infinitude and is not a Lean kernel check.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as R
from itertools import combinations
from math import gcd, factorial, isqrt
from pathlib import Path
import json

DATA = [
    (35, 36, 1, R(6,35), R(-41,35), -41),
    (6, 5, 1, R(35,6), R(41,6), 41),
    (1, 1, 2, R(210), R(-29), -29),
    (210, 181, 2, R(1,210), R(29,210), 29),
    (15, 14, 3, R(14,15), R(-1,15), -1),
    (14, 13, 3, R(15,14), R(1,14), 1),
]
SMALL = [(2,3,3), (3,2,3), (5,1,2), (7,1,2), (13,1,2), (181,1,2)]


def f(t: int) -> int:
    return 210*t*t+391*t+179


def primes_up_to(n: int) -> list[int]:
    sieve = bytearray(b'\x01')*(n+1)
    sieve[:2] = b'\x00\x00'
    for p in range(2, isqrt(n)+1):
        if sieve[p]:
            sieve[p*p:n+1:p] = b'\x00'*((n-p*p)//p+1)
    return [p for p in range(2, n+1) if sieve[p]]


def factor(n: int) -> dict[int, int]:
    if n < 1:
        raise ValueError('factor requires a positive integer')
    out: dict[int,int] = {}
    d = 2
    while d*d <= n:
        while n % d == 0:
            out[d] = out.get(d,0)+1
            n //= d
        d = 3 if d == 2 else d+2
    if n > 1:
        out[n] = out.get(n,0)+1
    return out


def valuation(n: int, p: int) -> int:
    if n < 1 or p < 2:
        raise ValueError('valuation requires n>0 and p>=2')
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


def carry_levels(n: int, p: int) -> list[int]:
    h, q = 1, p
    levels = []
    while q <= 2*n:
        # Remainder-based test, independent of the manuscript's quotient sum.
        if 2*(n % q) >= q:
            levels.append(h)
        h += 1
        q *= p
    return levels


def factorial_valuation(n: int, p: int) -> int:
    total = 0
    while n:
        n //= p
        total += n
    return total


def lift(p: int, exponent: int, target: int) -> int:
    u, modulus = 0, p
    assert (f(u)-target) % modulus == 0
    for _ in range(1, exponent):
        derivative = (420*u+391) % p
        assert gcd(derivative, p) == 1
        digit = ((target-f(u))//modulus * pow(derivative, -1, p)) % p
        u += digit*modulus
        modulus *= p
        assert (f(u)-target) % modulus == 0
    assert 0 <= u < p**exponent and u % p == 0
    return u


def crt(congruences: list[tuple[int,int]]) -> tuple[int,int]:
    t0, Q = 0, 1
    for residue, modulus in congruences:
        assert gcd(Q,modulus) == 1
        t0 += Q*((residue-t0)*pow(Q,-1,modulus) % modulus)
        Q *= modulus
        assert 0 <= t0 < Q
    for residue,modulus in congruences:
        assert (t0-residue) % modulus == 0 and Q % modulus == 0
    return t0,Q


def audit() -> dict:
    results: dict = {'status': 'finite exact checks only; not an infinitude proof'}
    # Coefficients, rather than sample polynomial evaluations.
    for a,b,j,alpha,beta,c in DATA:
        assert gcd(a,b) == 1
        assert (alpha*a*a,2*alpha*a*b+beta*a,alpha*b*b+beta*b-j) == (210,391,179)
        assert 420*R(-b,a)+391 == c
        assert 420 % a == 0
    for i in (0,2,4):
        a,b,j,*_ = DATA[i]
        aa,bb,jj,*_ = DATA[i+1]
        assert j == jj and (a*aa,a*bb+b*aa,b*bb) == (210,391,179+j)
    resultants = []
    for i,j in combinations(range(6),2):
        a,b,*_ = DATA[i]
        aa,bb,*_ = DATA[j]
        determinant = a*bb-aa*b
        fs = factor(abs(determinant))
        assert all(p <= 41 for p in fs)
        resultants.append({'i':i+1,'j':j+1,'resultant':determinant,'factorization':fs})
    results['resultants'] = resultants

    residue_tables = []
    for i,(a,b,j,alpha,beta,c) in enumerate(DATA, start=1):
        d = alpha.denominator
        if d == 1:
            assert alpha == 210 and beta < 0
            residue_tables.append({'i':i,'d':1,'bad_proportion':'0','special_negative_correction':True})
            continue
        assert a % d == 0 and gcd(b,d) == 1
        units = [m for m in range(d) if gcd(m,d)==1]
        image = Counter((alpha*m*m)%1 for m in units)
        assert len(set(image.values())) == 1
        assert R(0) not in image and R(1,2) not in image
        bad_m = [m for m in units if (alpha*m*m)%1 < R(1,2)]
        bad_p = [p for p in units if (alpha*((b*pow(p,-1,d))%d)**2)%1 < R(1,2)]
        assert len(bad_m)==len(bad_p)
        residue_tables.append({'i':i,'d':d,'phi':len(units),
            'fractional_parts':[str(x) for x in sorted(image)],
            'multiplicity_per_fraction':next(iter(image.values())),
            'bad_m':bad_m,'bad_prime_classes':bad_p,
            'bad_proportion':str(R(len(bad_m),len(units)))})
    assert [r['bad_proportion'] for r in residue_tables] == ['1/6','0','0','1/3','0','1/3']
    results['large_prime_residues'] = residue_tables

    support = {p for p,e,b in SMALL}
    assert set(factor(180*181*182)) == support
    congruences: list[tuple[int,int]] = []
    lifts = []
    for p,e,b in SMALL:
        assert sum(valuation(179+j,p) for j in range(1,4)) == e
        assert all(valuation(179+j,p)<b for j in range(1,4))
        target = 179 % p**b + p**b*(p**(2*e)-1)
        exponent = b+2*e
        u = lift(p,exponent,target)
        congruences.append((u,p**exponent))
        lifts.append({'p':p,'e':e,'b':b,'exponent':exponent,
                      'modulus':p**exponent,'target':target,'root':u})
    for p in primes_up_to(1000):
        if p not in support:
            congruences.append((0,p))
    t0,Q = crt(congruences)
    for v in (0,1,2,17,1000):
        n = f(t0+Q*v)
        for p in primes_up_to(1000):
            required = 2*sum(valuation(n+j,p) for j in range(1,4))
            assert len(carry_levels(n,p)) >= required
        for row in lifts:
            p,e,b = row['p'],row['e'],row['b']
            assert all((n//p**k)%p==p-1 for k in range(b,b+2*e))
    results['small_prime_lifts'] = lifts
    results['CRT'] = {'t0':str(t0),'Q':str(Q),'Q_digits':len(str(Q)),
                      'number_of_prime_power_moduli':len(congruences)}

    # Numerical comparisons proved by exact rational arithmetic.
    eta = R(1,10**6)
    assert min(R(2,J)-R(2,J+1) for J in range(4,40))==R(1,780)>2*eta
    assert sum(range(4,41))==814
    strip_bound = 6*eta*814/(1-20*eta)
    assert strip_bound < R(4885,10**6) < R(1,100)
    rho=R(1001,2000)
    assert rho**-2<4
    assert 2*(R(2000,1001)-1)/(R(2000,1001)+1)>R(3,5)
    assert sum(R(3**r,factorial(r)) for r in range(9))>20
    assert sum(R(7,10)**r/factorial(r) for r in range(4))>2
    total=R(6,1000)+R(1,100)+R(3,8)+R(1,100)+R(7,12)
    assert total==R(2953,3000)<R(99,100)
    results['constants']={'boundary_upper_bound':str(strip_bound),
                         'failure_budget':str(total),
                         'slack_to_99_percent':str(R(99,100)-total),
                         'five_errors_of_1_over_1000':str(total+R(5,1000))}

    n=f(61)
    assert n==805440
    vals: Counter[int]=Counter()
    for a,b,*_ in DATA:
        vals.update(factor(a*61+b))
    certificate=[]
    for p,e in sorted(vals.items()):
        levels=carry_levels(n,p)
        c=factorial_valuation(2*n,p)-2*factorial_valuation(n,p)
        assert c==len(levels)>=2*e
        assert factorial_valuation(2*n,p)>=2*factorial_valuation(n+3,p)
        certificate.append({'p':p,'A_exponent':e,'carry_levels':levels,
                            'carries':c,'required':2*e})
    results['example']={'t':61,'n':n,'A':(n+1)*(n+2)*(n+3),'certificate':certificate}

    def succeeds(t: int) -> bool:
        n=f(t)
        val: Counter[int]=Counter()
        for a,b,*_ in DATA:
            val.update(factor(a*t+b))
        return all(len(carry_levels(n,p))>=2*e for p,e in val.items())
    successes = [t for t in range(1,10001) if succeeds(t)]
    assert len(successes)==1612
    results['scan']={'range':[1,10000],'count':len(successes),
                     'first_20_successes':successes[:20]}
    return results


if __name__ == '__main__':
    result=audit()
    output=Path(__file__).with_name('checks_output.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print('Exact polynomial, derivative, resultant, residue, Hensel, CRT, and constant checks passed.')
    print('CRT modulus digits:',result['CRT']['Q_digits'])
    print('Hensel roots:',[(r['p'],r['modulus'],r['root']) for r in result['small_prime_lifts']])
    print('Bad prime classes:',[(r['i'],r.get('bad_prime_classes',[])) for r in result['large_prime_residues']])
    print('Example:',result['example']['n'],'; scan count:',result['scan']['count'])
    print('This is a finite arithmetic audit, not an infinitude or Lean verification.')
    print('Output:',output)
