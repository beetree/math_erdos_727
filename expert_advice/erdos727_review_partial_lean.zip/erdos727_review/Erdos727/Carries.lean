import Erdos727.Algebra

/-! Arithmetic carry criteria. UNCOMPILED proof draft; see README.md. -/

namespace Erdos727

/-- The carry out of the first `h` base-`p` digits when doubling `n`. -/
def CarryAt (n p h : ℕ) : Prop := p ^ h ≤ 2 * (n % p ^ h)

instance (n p h : ℕ) : Decidable (CarryAt n p h) := by
  unfold CarryAt
  infer_instance

/-- A finite, efficiently evaluable count; no factorial or binomial is evaluated. -/
def carryCount (n p : ℕ) : ℕ :=
  ((Finset.Ico 1 (Nat.log p (2 * n) + 1)).filter (CarryAt n p)).card

/-- The manuscript's event (5.2), apart from the linear divisibility condition. -/
def NoExtraCarry (n p : ℕ) : Prop := ∀ h : ℕ, 2 ≤ h → ¬ CarryAt n p h

theorem binomial_factorization_eq_carryCount (n : ℕ) {p : ℕ} (hp : p.Prime) :
    (B n).factorization p = carryCount n p := by
  have h := Nat.factorization_choose' (n := n) (k := n)
    (b := Nat.log p (n + n) + 1) hp (Nat.lt_succ_self _)
  simpa only [B, carryCount, CarryAt, two_mul] using h

theorem factorization_square_apply (a p : ℕ) (ha : a ≠ 0) :
    (a ^ 2).factorization p = 2 * a.factorization p := by
  rw [pow_two, Nat.factorization_mul ha ha, Finsupp.add_apply]
  omega

/-- The exact primewise criterion, not merely a sufficient numerical test. -/
theorem good3_iff_carries (n : ℕ) :
    Good3 n ↔ ∀ p : ℕ, p.Prime → 2 * (A n).factorization p ≤ carryCount n p := by
  rw [good3_iff_binomial]
  have ha : A n ≠ 0 := (A_pos n).ne'
  have hb : B n ≠ 0 := (B_pos n).ne'
  rw [← Nat.factorization_prime_le_iff_dvd (pow_ne_zero 2 ha) hb]
  constructor
  · intro h p hp
    have h' := h p hp
    rwa [factorization_square_apply _ _ ha,
      binomial_factorization_eq_carryCount n hp] at h'
  · intro h p hp
    rw [factorization_square_apply _ _ ha,
      binomial_factorization_eq_carryCount n hp]
    exact h p hp

theorem carry_requirement_zero {n p : ℕ} (h : ¬ p ∣ A n) :
    2 * (A n).factorization p ≤ carryCount n p := by
  rw [Nat.factorization_eq_zero_of_not_dvd h]
  simp

/-- The units digit `p-j` is already large enough to produce a carry. -/
theorem first_carry {n p j : ℕ} (hp : 6 < p) (hj₁ : 1 ≤ j) (hj₃ : j ≤ 3)
    (hmod : n % p = p - j) : CarryAt n p 1 := by
  simp only [CarryAt, pow_one, hmod]
  omega

/-- Any prescribed collection of distinct carry levels supplies that many carries. -/
theorem card_le_carryCount {n p : ℕ} (s : Finset ℕ)
    (hs : ∀ h ∈ s, 1 ≤ h ∧ h < Nat.log p (2 * n) + 1 ∧ CarryAt n p h) :
    s.card ≤ carryCount n p := by
  apply Finset.card_le_card
  intro h hh
  obtain ⟨h₁, h₂, h₃⟩ := hs h hh
  exact Finset.mem_filter.mpr ⟨Finset.mem_Ico.mpr ⟨h₁, h₂⟩, h₃⟩

/-- Repeated-factor exclusion reduces a positive prime exponent to exactly one. -/
theorem factorization_eq_one {a p : ℕ} (hp : p.Prime) (ha : a ≠ 0)
    (hd : p ∣ a) (hsq : ¬ p ^ 2 ∣ a) : a.factorization p = 1 := by
  have hlo : 1 ≤ a.factorization p := (hp.dvd_iff_one_le_factorization ha).mp hd
  have hhi : ¬ 2 ≤ a.factorization p := by
    intro h
    exact hsq ((hp.pow_dvd_iff_le_factorization ha).mpr h)
  omega

end Erdos727
