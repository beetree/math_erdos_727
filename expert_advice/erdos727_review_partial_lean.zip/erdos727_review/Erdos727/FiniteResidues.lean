import Erdos727.Algebra

/-!
Exact finite parts of §§3 and 11. UNCOMPILED proof draft.
The third factor (index 2) is excluded from the bad-residue calculation:
its *negative* correction makes it favorable despite integral alpha*m^2.
-/

set_option maxRecDepth 8192
set_option maxHeartbeats 8000000

namespace Erdos727

def alpha : Fin 6 → ℚ := ![6 / 35, 35 / 6, 210, 1 / 210, 14 / 15, 15 / 14]
def beta : Fin 6 → ℚ := ![-41 / 35, 41 / 6, -29, 29 / 210, -1 / 15, 1 / 14]
def derivRoot : Fin 6 → ℤ := ![-41, 41, -29, 29, -1, 1]
def derivMultiplier : Fin 6 → ℤ := ![12, 70, 420, 2, 28, 30]

def denominator : Fin 6 → ℕ := ![35, 6, 1, 210, 15, 14]
def numerator : Fin 6 → ℕ := ![6, 35, 210, 1, 14, 15]

theorem primitive_forms : ∀ i : Fin 6, Nat.Coprime (slope i) (intercept i) := by
  decide

theorem identity_in_linear_coordinate (i : Fin 6) (t : ℚ) :
    210 * t ^ 2 + 391 * t + 179 =
      alpha i * ((slope i : ℚ) * t + intercept i) ^ 2 +
      beta i * ((slope i : ℚ) * t + intercept i) - shift i := by
  fin_cases i <;> norm_num [alpha, beta, slope, intercept, shift] <;> ring

theorem derivative_identity (i : Fin 6) (t : ℤ) :
    420 * t + 391 - derivRoot i =
      derivMultiplier i * ((slope i : ℤ) * t + intercept i) := by
  fin_cases i <;> norm_num [derivRoot, derivMultiplier, slope, intercept] <;> ring

theorem rational_coefficients (i : Fin 6) :
    alpha i = (numerator i : ℚ) / denominator i := by
  fin_cases i <;> norm_num [alpha, numerator, denominator]

theorem denominator_conditions : ∀ i : Fin 6,
    0 < denominator i ∧ denominator i ∣ slope i ∧
    Nat.Coprime (intercept i) (denominator i) := by
  decide

def unitResidues (d : ℕ) : Finset ℕ :=
  (Finset.range d).filter (fun m => Nat.Coprime m d)

def badMResidues (i : Fin 6) : Finset ℕ :=
  if i = 2 then ∅ else
    (unitResidues (denominator i)).filter
      (fun m => 2 * ((numerator i * m ^ 2) % denominator i) < denominator i)

/-- A finite relation encodes m = b*p^{-1}; it does not need a choice of inverse. -/
def badPrimeResidues (i : Fin 6) : Finset ℕ :=
  (unitResidues (denominator i)).filter fun p =>
    ∃ m : Fin (denominator i),
      (m : ℕ) ∈ badMResidues i ∧
      (p * (m : ℕ)) % denominator i = intercept i % denominator i

def unitCount : Fin 6 → ℕ := ![24, 2, 1, 48, 8, 6]
def badCount : Fin 6 → ℕ := ![4, 0, 0, 16, 0, 2]

theorem unit_counts : ∀ i : Fin 6,
    (unitResidues (denominator i)).card = unitCount i := by decide

theorem bad_m_counts : ∀ i : Fin 6, (badMResidues i).card = badCount i := by decide

theorem bad_prime_counts : ∀ i : Fin 6,
    (badPrimeResidues i).card = badCount i := by decide

theorem bad_prime_classes_1 : badPrimeResidues 0 = {1, 6, 29, 34} := by decide

theorem bad_prime_classes_4 : badPrimeResidues 3 =
    {1, 23, 29, 37, 41, 47, 71, 103, 107, 139, 163, 169, 173, 181, 187, 209} := by
  decide

theorem bad_prime_classes_6 : badPrimeResidues 5 = {1, 13} := by decide

theorem other_bad_prime_classes :
    badPrimeResidues 1 = ∅ ∧ badPrimeResidues 2 = ∅ ∧ badPrimeResidues 4 = ∅ := by
  decide

/-- There is no exact integer or half-integer in the five nonexceptional residue tables. -/
theorem no_residue_boundary : ∀ i : Fin 6, i ≠ 2 → ∀ m : Fin (denominator i),
    Nat.Coprime (m : ℕ) (denominator i) →
      (numerator i * (m : ℕ) ^ 2) % denominator i ≠ 0 ∧
      2 * ((numerator i * (m : ℕ) ^ 2) % denominator i) ≠ denominator i := by
  decide

theorem total_bad_proportion :
    (4 : ℚ) / 24 + 0 / 2 + 0 / 1 + 16 / 48 + 0 / 8 + 2 / 6 = 5 / 6 := by
  norm_num

/-- The signed determinants certify disjoint roots for sufficiently large primes. -/
def resultant (i j : Fin 6) : ℤ :=
  (slope i : ℤ) * intercept j - (slope j : ℤ) * intercept i

theorem within_pair_resultants :
    resultant 0 1 = -41 ∧ resultant 2 3 = -29 ∧ resultant 4 5 = -1 := by decide

end Erdos727
