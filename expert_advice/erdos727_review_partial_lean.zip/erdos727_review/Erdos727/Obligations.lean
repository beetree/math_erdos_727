import Erdos727.Carries
import Erdos727.Counting

/-!
# Exact outstanding obligations

UNCOMPILED. No instance of `RequiredEstimates` is constructed here.
The predicates below retain the manuscript's exceptional events. In particular,
the missing prime-distribution and equidistribution arguments are NOT axioms.
The final theorem in this file is explicitly conditional on all six obligations.
-/

namespace Erdos727

noncomputable section

/-- Select the parameters in a dyadic block satisfying a possibly nondecidable property. -/
def parametersWhere (X : ℕ) (P : ℕ → Prop) : Finset ℕ := by
  classical
  exact (block X).filter P

def eta : ℝ := 1 / 1000000
def delta : ℝ := 1 / 20
def bandExponent (j : ℕ) : ℝ := 2 / (j : ℝ)

def RepeatedAt (Q t₀ v : ℕ) : Prop :=
  ∃ p : ℕ, p.Prime ∧ 1000 < p ∧ ∃ i : Fin 6, p ^ 2 ∣ linOn Q t₀ i v

def FailureAt (Q t₀ v p : ℕ) : Prop :=
  p.Prime ∧ 1000 < p ∧
    (∃ i : Fin 6, p ∣ linOn Q t₀ i v) ∧ NoExtraCarry (F Q t₀ v) p

def MediumPrime (X p : ℕ) : Prop :=
  ∃ J : ℕ, 4 ≤ J ∧ J ≤ 39 ∧
    Real.rpow (X : ℝ) (bandExponent (J + 1) + eta) < (p : ℝ) ∧
    (p : ℝ) ≤ Real.rpow (X : ℝ) (bandExponent J - eta)

def StripPrime (X p : ℕ) : Prop :=
  ∃ j : ℕ, 4 ≤ j ∧ j ≤ 40 ∧
    Real.rpow (X : ℝ) (bandExponent j - eta) ≤ (p : ℝ) ∧
    (p : ℝ) ≤ Real.rpow (X : ℝ) (bandExponent j + eta)

def repeatedSet (Q t₀ X : ℕ) : Finset ℕ :=
  parametersWhere X (RepeatedAt Q t₀)

def smallSet (Q t₀ X : ℕ) : Finset ℕ :=
  parametersWhere X fun v => ∃ p : ℕ,
    FailureAt Q t₀ v p ∧ (p : ℝ) ≤ Real.rpow (X : ℝ) delta

def mediumSet (Q t₀ X : ℕ) : Finset ℕ :=
  parametersWhere X fun v => ∃ p : ℕ, FailureAt Q t₀ v p ∧ MediumPrime X p

def stripSet (Q t₀ X : ℕ) : Finset ℕ :=
  parametersWhere X fun v => ∃ p : ℕ,
    p.Prime ∧ 1000 < p ∧ (∃ i : Fin 6, p ∣ linOn Q t₀ i v) ∧ StripPrime X p

def largeSet (Q t₀ X : ℕ) : Finset ℕ :=
  parametersWhere X fun v => ∃ p : ℕ,
    FailureAt Q t₀ v p ∧ Real.rpow (X : ℝ) (1 / 2 + eta) < (p : ℝ)

def actualEvents (Q t₀ : ℕ) : Fin 5 → ℕ → Finset ℕ :=
  ![repeatedSet Q t₀, smallSet Q t₀, mediumSet Q t₀, stripSet Q t₀, largeSet Q t₀]

/--
UNPROVED INPUTS. Every field must be established for the selected progression.
The arithmetic certificates do not themselves instantiate this proposition.

* coverage: §§3–5 and the prime-range covering in §§9–12;
* repeated: §5 (square divisors of primitive linear forms);
* small: §§4, 6, 7 (lifting, digit count, weighted harmonic prime sum);
* medium: §§6, 8, 9 (uniform quadratic sums, uniform box discrepancy, summation);
* strips: §§6, 10 (prime harmonic sums and endpoint bounds);
* large: §§6, 11 (residue stability and prime harmonic sums in fixed classes).
-/
structure RequiredEstimates (Q t₀ : ℕ) : Prop where
  modulus_positive : 1 ≤ Q
  coverage : ∀ X : ℕ, badBlock Q t₀ X ⊆ union5 (actualEvents Q t₀) X
  repeated : UpperDensityBound (repeatedSet Q t₀) (3 / 500)
  small : UpperDensityBound (smallSet Q t₀) (1 / 100)
  medium : UpperDensityBound (mediumSet Q t₀) (3 / 8)
  strips : UpperDensityBound (stripSet Q t₀) (1 / 100)
  large : UpperDensityBound (largeSet Q t₀) (7 / 12)

/-- Conditional only; there is no unconditional theorem `K3` in this project. -/
theorem k3_from_required_estimates {Q t₀ : ℕ} (h : RequiredEstimates Q t₀) : K3 := by
  apply k3_of_exceptional_bounds Q t₀ h.modulus_positive (actualEvents Q t₀)
  · exact h.coverage
  · simpa [actualEvents] using h.repeated
  · simpa [actualEvents] using h.small
  · simpa [actualEvents] using h.medium
  · simpa [actualEvents] using h.strips
  · simpa [actualEvents] using h.large

end
end Erdos727
