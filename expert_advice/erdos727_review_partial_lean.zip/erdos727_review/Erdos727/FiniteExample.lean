import Erdos727.Carries

/-!
The finite example in §13, reduced to small exact computations and Kummer.
UNCOMPILED proof draft. Python independently checks the same mathematical facts.
No factorial of 805443 or binomial coefficient of 1610880 is evaluated by `decide`.
-/

set_option maxRecDepth 8192
set_option maxHeartbeats 8000000

namespace Erdos727

def examplePrime : Fin 11 → ℕ := ![2, 3, 7, 11, 13, 17, 31, 53, 167, 929, 1181]
def exampleExponent : Fin 11 → ℕ := ![1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1]
def exampleCarries : Fin 11 → ℕ := ![6, 9, 5, 2, 3, 5, 2, 2, 2, 2, 2]

def exampleValuation (p : ℕ) : ℕ :=
  ∑ i : Fin 11, if examplePrime i = p then exampleExponent i else 0

theorem example_parameter : f 61 = 805440 := by decide

theorem example_primality : ∀ i : Fin 11, (examplePrime i).Prime := by decide

theorem example_A_product :
    A 805440 = ∏ i : Fin 11, examplePrime i ^ exampleExponent i := by decide

theorem example_A_factorization (p : ℕ) :
    (A 805440).factorization p = exampleValuation p := by
  rw [example_A_product]
  rw [Nat.factorization_prod_apply (fun i _ =>
    pow_ne_zero _ (example_primality i).ne_zero)]
  unfold exampleValuation
  apply Finset.sum_congr rfl
  intro i _
  rw [(example_primality i).factorization_pow]
  simp [Finsupp.single_apply, eq_comm]

theorem example_carry_table : ∀ i : Fin 11,
    carryCount 805440 (examplePrime i) = exampleCarries i := by decide

theorem example_carry_inequalities : ∀ i : Fin 11,
    2 * exampleValuation (examplePrime i) ≤ carryCount 805440 (examplePrime i) := by
  decide

/-- This is a proof draft of one example, not an infinitude theorem. -/
theorem good3_805440 : Good3 805440 := by
  apply (good3_iff_carries 805440).mpr
  intro p _hp
  rw [example_A_factorization]
  by_cases h : ∃ i : Fin 11, examplePrime i = p
  · obtain ⟨i, rfl⟩ := h
    exact example_carry_inequalities i
  · have hz : exampleValuation p = 0 := by
      unfold exampleValuation
      apply Finset.sum_eq_zero
      intro i _
      exact if_neg (fun hi => h ⟨i, hi⟩)
    rw [hz]
    simp

theorem good2_805440 : Good2 805440 := good2_of_good3 good3_805440

end Erdos727
