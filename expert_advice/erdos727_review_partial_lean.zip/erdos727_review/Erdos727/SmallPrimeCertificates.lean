import Erdos727.Carries

/-!
Concrete local lifting and CRT certificates for §4. UNCOMPILED proof draft.
The same integers are independently checked in checks.py / checks_output.json.
These finite certificates are NOT the missing asymptotic estimates.
-/

set_option maxRecDepth 8192
set_option maxHeartbeats 12000000

namespace Erdos727

namespace CRTCertificate

def smallPrime : Fin 6 → ℕ := ![2, 3, 5, 7, 13, 181]
def e : Fin 6 → ℕ := ![3, 2, 1, 1, 1, 1]
def b : Fin 6 → ℕ := ![3, 3, 2, 2, 2, 2]
def localRoot : Fin 6 → ℕ := ![248, 1107, 300, 196, 17238, 491349478]
def localModulus (i : Fin 6) : ℕ := smallPrime i ^ (b i + 2 * e i)
def target (i : Fin 6) : ℕ :=
  179 % (smallPrime i ^ b i) + smallPrime i ^ b i * (smallPrime i ^ (2 * e i) - 1)

/-- A concrete modulus satisfying the manuscript's product formula. -/
def Q : ℕ := 2042111241071937784211290299224843815793865836529035059920749521857314770525208668972616551161935396344351581999155743721144965316544048183038181298843867958864299780640747584730644121425723119036667394674081799041137638402916472964266834779347198226461094264207260628203700630831555315550411368308853409041598737390889475896790991473169830947448984735051907625825051574161238081878972157060580864887156959958573124754099625310761280000

/-- The representative in [0,Q) obtained from the six local lifts and other roots 0. -/
def t₀ : ℕ := 552319851417788379422952031470646085314637490077748300939158775472168902965044816741684514296464166024830898345658242853434199300025124992568744521876286239807362229255715881016594185722608400310826143318408927750286909370975560356234478495574966218156042575510420769345577499167907185404732469097564427570241822823597360148724395672520222414980748400427001459997324820583506154921074868130234431230977731688852405107613958663029847800

def special : Finset ℕ := {2, 3, 5, 7, 13, 181}

def modulusExponent (p : ℕ) : ℕ :=
  if p = 2 then 9 else if p = 3 then 7 else
  if p = 5 ∨ p = 7 ∨ p = 13 ∨ p = 181 then 4 else 1

theorem positive_modulus : 1 ≤ Q := by decide

theorem representative_range : t₀ < Q := by decide

theorem local_primality : ∀ i : Fin 6, (smallPrime i).Prime := by decide

theorem local_lifts : ∀ i : Fin 6,
    localRoot i < localModulus i ∧ localRoot i % smallPrime i = 0 ∧
    f (localRoot i) % localModulus i = target i := by decide

theorem target_range : ∀ i : Fin 6, target i < localModulus i := by decide

theorem crt_local_data : ∀ i : Fin 6,
    Q % localModulus i = 0 ∧ t₀ % localModulus i = localRoot i := by decide

theorem crt_other_primes : ∀ p : Fin 1001,
    Nat.Prime (p : ℕ) → (p : ℕ) ∉ special → Q % (p : ℕ) = 0 ∧ t₀ % (p : ℕ) = 0 := by
  decide

theorem modulus_product :
    Q = ∏ p ∈ (Finset.range 1001).filter Nat.Prime, p ^ modulusExponent p := by
  decide

/-- Checks the complete block of 2e carry digits in each prescribed low residue. -/
theorem prescribed_digit_carries : ∀ i : Fin 6, ∀ h : Fin (2 * e i),
    CarryAt (target i) (smallPrime i) (b i + (h : ℕ) + 1) := by decide

/-- The finite CRT certificates give the required polynomial congruence for every v. -/
theorem progression_target (i : Fin 6) (v : ℕ) :
    F Q t₀ v % localModulus i = target i := by
  have hdiv : localModulus i ∣ Q := Nat.dvd_of_mod_eq_zero (crt_local_data i).1
  rw [F_mod hdiv]
  calc
    f t₀ % localModulus i = f (localRoot i) % localModulus i := by
      apply f_mod_eq_of_mod_eq
      rw [(crt_local_data i).2, Nat.mod_eq_of_lt (local_lifts i).1]
    _ = target i := (local_lifts i).2.2

end CRTCertificate
end Erdos727
