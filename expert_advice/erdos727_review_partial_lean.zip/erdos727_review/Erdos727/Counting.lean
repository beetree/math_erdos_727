import Erdos727.Algebra

/-!
The final counting-to-infinitude implication, with ALL missing input explicit.
UNCOMPILED proof draft. The hypotheses of `k3_of_exceptional_bounds` are NOT
proved or instantiated in this project. They must not be replaced by axioms.
-/

namespace Erdos727

open Finset

def block (X : ℕ) : Finset ℕ := Finset.Ico X (2 * X)

noncomputable def goodBlock (Q t₀ X : ℕ) : Finset ℕ := by
  classical
  exact (block X).filter (fun v => Good3 (F Q t₀ v))

noncomputable def badBlock (Q t₀ X : ℕ) : Finset ℕ := by
  classical
  exact (block X).filter (fun v => ¬ Good3 (F Q t₀ v))

def union5 (E : Fin 5 → ℕ → Finset ℕ) (X : ℕ) : Finset ℕ :=
  (((E 0 X ∪ E 1 X) ∪ E 2 X) ∪ E 3 X) ∪ E 4 X

def UpperDensityBound (E : ℕ → Finset ℕ) (c : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ X₀ : ℕ, ∀ X : ℕ, X₀ ≤ X →
    ((E X).card : ℝ) ≤ (c + ε) * (X : ℝ)

/-- The stronger, dyadic parameter statement (1.1). -/
def DyadicDensity (Q t₀ : ℕ) : Prop :=
  ∃ X₀ : ℕ, ∀ X : ℕ, X₀ ≤ X →
    (X : ℝ) / 100 ≤ ((goodBlock Q t₀ X).card : ℝ)

theorem block_card (X : ℕ) : (block X).card = X := by
  simp only [block, Nat.card_Ico]
  omega

theorem good_bad_partition (Q t₀ X : ℕ) :
    (goodBlock Q t₀ X).card + (badBlock Q t₀ X).card = X := by
  classical
  have h := Finset.card_filter_add_card_filter_not (s := block X)
    (fun v => Good3 (F Q t₀ v))
  simpa only [goodBlock, badBlock, block_card] using h

theorem union5_card_le (E : Fin 5 → ℕ → Finset ℕ) (X : ℕ) :
    (union5 E X).card ≤
      (E 0 X).card + (E 1 X).card + (E 2 X).card + (E 3 X).card + (E 4 X).card := by
  have h₁ := Finset.card_union_le (E 0 X) (E 1 X)
  have h₂ := Finset.card_union_le (E 0 X ∪ E 1 X) (E 2 X)
  have h₃ := Finset.card_union_le ((E 0 X ∪ E 1 X) ∪ E 2 X) (E 3 X)
  have h₄ := Finset.card_union_le (((E 0 X ∪ E 1 X) ∪ E 2 X) ∪ E 3 X) (E 4 X)
  unfold union5
  omega

theorem exact_failure_budget :
    (3 : ℚ) / 500 + 1 / 100 + 3 / 8 + 1 / 100 + 7 / 12 = 2953 / 3000 := by
  norm_num

theorem failure_budget_slack : (2953 : ℚ) / 3000 < 99 / 100 := by norm_num

/-- Five epsilon allowances of 1/1000 still leave more than a 1% good set. -/
theorem budget_with_errors :
    (3 / 500 + 1 / 1000 : ℚ) + (1 / 100 + 1 / 1000) +
      (3 / 8 + 1 / 1000) + (1 / 100 + 1 / 1000) + (7 / 12 + 1 / 1000) =
      371 / 375 := by norm_num

/--
Proof draft of an implication, not a construction of
exceptional-set bounds. Coverage and all five asymptotic estimates are hypotheses.
-/
theorem density_of_exceptional_bounds
    (Q t₀ : ℕ) (E : Fin 5 → ℕ → Finset ℕ)
    (hcover : ∀ X : ℕ, badBlock Q t₀ X ⊆ union5 E X)
    (hrep : UpperDensityBound (E 0) (3 / 500))
    (hsmall : UpperDensityBound (E 1) (1 / 100))
    (hmedium : UpperDensityBound (E 2) (3 / 8))
    (hstrip : UpperDensityBound (E 3) (1 / 100))
    (hlarge : UpperDensityBound (E 4) (7 / 12)) :
    DyadicDensity Q t₀ := by
  obtain ⟨T₀, H₀⟩ := hrep (1 / 1000) (by norm_num)
  obtain ⟨T₁, H₁⟩ := hsmall (1 / 1000) (by norm_num)
  obtain ⟨T₂, H₂⟩ := hmedium (1 / 1000) (by norm_num)
  obtain ⟨T₃, H₃⟩ := hstrip (1 / 1000) (by norm_num)
  obtain ⟨T₄, H₄⟩ := hlarge (1 / 1000) (by norm_num)
  refine ⟨T₀ + T₁ + T₂ + T₃ + T₄, ?_⟩
  intro X hX
  have H₀X := H₀ X (by omega)
  have H₁X := H₁ X (by omega)
  have H₂X := H₂ X (by omega)
  have H₃X := H₃ X (by omega)
  have H₄X := H₄ X (by omega)
  have hnat : (badBlock Q t₀ X).card ≤
      (E 0 X).card + (E 1 X).card + (E 2 X).card + (E 3 X).card + (E 4 X).card :=
    (Finset.card_le_card (hcover X)).trans (union5_card_le E X)
  have hreal : ((badBlock Q t₀ X).card : ℝ) ≤
      ((E 0 X).card : ℝ) + ((E 1 X).card : ℝ) + ((E 2 X).card : ℝ) +
      ((E 3 X).card : ℝ) + ((E 4 X).card : ℝ) := by
    exact_mod_cast hnat
  have hbad : ((badBlock Q t₀ X).card : ℝ) ≤ (371 / 375 : ℝ) * (X : ℝ) := by
    linarith
  have hpartition : ((goodBlock Q t₀ X).card : ℝ) +
      ((badBlock Q t₀ X).card : ℝ) = (X : ℝ) := by
    exact_mod_cast good_bad_partition Q t₀ X
  have hnonneg : 0 ≤ (X : ℝ) := Nat.cast_nonneg X
  linarith

theorem infinite_of_unbounded_nat {s : Set ℕ}
    (h : ∀ M : ℕ, ∃ n : ℕ, n ∈ s ∧ M < n) : s.Infinite := by
  intro hs
  obtain ⟨M, hM⟩ := hs.bddAbove
  obtain ⟨n, hn, hgt⟩ := h M
  exact (not_lt_of_ge (hM hn)) hgt

/-- Infinitude follows from the manuscript's actual parameter-counting statement. -/
theorem k3_of_dyadicDensity {Q t₀ : ℕ} (hQ : 1 ≤ Q) (hd : DyadicDensity Q t₀) :
    K3 := by
  classical
  apply infinite_of_unbounded_nat
  intro M
  obtain ⟨X₀, H⟩ := hd
  let X := max X₀ (M + 1)
  have hX₀ : X₀ ≤ X := le_max_left _ _
  have hMX : M < X := lt_of_lt_of_le (Nat.lt_succ_self M) (le_max_right _ _)
  have hXpos : 0 < X := by omega
  have hcount := H X hX₀
  have hposR : (0 : ℝ) < ((goodBlock Q t₀ X).card : ℝ) :=
    lt_of_lt_of_le (div_pos (by exact_mod_cast hXpos) (by norm_num)) hcount
  have hposN : 0 < (goodBlock Q t₀ X).card := by exact_mod_cast hposR
  obtain ⟨v, hv⟩ := Finset.card_pos.mp hposN
  have hv' : v ∈ block X ∧ Good3 (F Q t₀ v) := by
    simpa only [goodBlock, Finset.mem_filter] using hv
  have hXv : X ≤ v := (Finset.mem_Ico.mp hv'.1).1
  refine ⟨F Q t₀ v, hv'.2, ?_⟩
  exact (hMX.trans_le hXv).trans_le (le_F Q t₀ v hQ)

/--
CONDITIONAL theorem only. This project's missing work is to supply these hypotheses
for the actual exceptional sets in Obligations.lean, without assuming the conclusion.
-/
theorem k3_of_exceptional_bounds
    (Q t₀ : ℕ) (hQ : 1 ≤ Q) (E : Fin 5 → ℕ → Finset ℕ)
    (hcover : ∀ X : ℕ, badBlock Q t₀ X ⊆ union5 E X)
    (hrep : UpperDensityBound (E 0) (3 / 500))
    (hsmall : UpperDensityBound (E 1) (1 / 100))
    (hmedium : UpperDensityBound (E 2) (3 / 8))
    (hstrip : UpperDensityBound (E 3) (1 / 100))
    (hlarge : UpperDensityBound (E 4) (7 / 12)) : K3 := by
  exact k3_of_dyadicDensity hQ
    (density_of_exceptional_bounds Q t₀ E hcover hrep hsmall hmedium hstrip hlarge)

end Erdos727
