import Mathlib

/-!
# Erdős 727, k = 3: arithmetic proof draft

STATUS: This file has not been run through Lean. See README.md.
It contains no claim that the infinitude theorem has been proved.
Indices 0,...,5 correspond to the manuscript's indices 1,...,6.
-/

namespace Erdos727

/-- The polynomial used in the manuscript. -/
def f (t : ℕ) : ℕ := 210 * t ^ 2 + 391 * t + 179

def A (n : ℕ) : ℕ := (n + 1) * (n + 2) * (n + 3)
def B (n : ℕ) : ℕ := (2 * n).choose n

def Good3 (n : ℕ) : Prop := (n + 3).factorial ^ 2 ∣ (2 * n).factorial
def Good2 (n : ℕ) : Prop := (n + 2).factorial ^ 2 ∣ (2 * n).factorial

/-- This is the unconditional target, a definition, NOT a proved theorem. -/
def K3 : Prop := Set.Infinite {n : ℕ | Good3 n}

def slope : Fin 6 → ℕ := ![35, 6, 1, 210, 15, 14]
def intercept : Fin 6 → ℕ := ![36, 5, 1, 181, 14, 13]
def shift : Fin 6 → ℕ := ![1, 1, 2, 2, 3, 3]
def lin (i : Fin 6) (t : ℕ) : ℕ := slope i * t + intercept i

def F (Q t₀ v : ℕ) : ℕ := f (t₀ + Q * v)
def linOn (Q t₀ : ℕ) (i : Fin 6) (v : ℕ) : ℕ := lin i (t₀ + Q * v)

theorem f_add_one (t : ℕ) : f t + 1 = (35 * t + 36) * (6 * t + 5) := by
  unfold f
  ring

theorem f_add_two (t : ℕ) : f t + 2 = (t + 1) * (210 * t + 181) := by
  unfold f
  ring

theorem f_add_three (t : ℕ) : f t + 3 = (15 * t + 14) * (14 * t + 13) := by
  unfold f
  ring

theorem A_f_product (t : ℕ) :
    A (f t) = lin 0 t * lin 1 t * lin 2 t * lin 3 t * lin 4 t * lin 5 t := by
  simp only [A, f_add_one, f_add_two, f_add_three]
  norm_num [lin, slope, intercept] <;> ring

theorem lin_dvd_shift (i : Fin 6) (t : ℕ) : lin i t ∣ f t + shift i := by
  fin_cases i
  · simpa [lin, slope, intercept, shift, f_add_one] using
      (dvd_mul_right (35 * t + 36) (6 * t + 5))
  · simpa [lin, slope, intercept, shift, f_add_one, mul_comm] using
      (dvd_mul_right (6 * t + 5) (35 * t + 36))
  · simpa [lin, slope, intercept, shift, f_add_two] using
      (dvd_mul_right (t + 1) (210 * t + 181))
  · simpa [lin, slope, intercept, shift, f_add_two, mul_comm] using
      (dvd_mul_right (210 * t + 181) (t + 1))
  · simpa [lin, slope, intercept, shift, f_add_three] using
      (dvd_mul_right (15 * t + 14) (14 * t + 13))
  · simpa [lin, slope, intercept, shift, f_add_three, mul_comm] using
      (dvd_mul_right (14 * t + 13) (15 * t + 14))

theorem slope_pos (i : Fin 6) : 0 < slope i := by fin_cases i <;> decide

theorem intercept_pos (i : Fin 6) : 0 < intercept i := by fin_cases i <;> decide

theorem lin_pos (i : Fin 6) (t : ℕ) : 0 < lin i t := by
  have := intercept_pos i
  unfold lin
  omega

theorem A_pos (n : ℕ) : 0 < A n := by unfold A; positivity

theorem B_pos (n : ℕ) : 0 < B n := by
  exact Nat.choose_pos (by omega : n ≤ 2 * n)

theorem le_f (t : ℕ) : t ≤ f t := by
  unfold f
  nlinarith

theorem f_strictMono : StrictMono f := by
  intro a b hab
  have hsq : a * a ≤ b * b := Nat.mul_le_mul hab.le hab.le
  simp only [f, pow_two]
  nlinarith

theorem le_F (Q t₀ v : ℕ) (hQ : 1 ≤ Q) : v ≤ F Q t₀ v := by
  have h : v ≤ t₀ + Q * v := by nlinarith
  exact h.trans (le_f (t₀ + Q * v))

theorem F_strictMono {Q t₀ : ℕ} (hQ : 1 ≤ Q) : StrictMono (F Q t₀) := by
  intro a b hab
  apply f_strictMono
  nlinarith

theorem factorial_add_three (n : ℕ) :
    (n + 3).factorial = n.factorial * A n := by
  calc
    (n + 3).factorial =
        (n + 3) * ((n + 2) * ((n + 1) * n.factorial)) := by
          rw [show n + 3 = (n + 2) + 1 by omega, Nat.factorial_succ,
              show n + 2 = (n + 1) + 1 by omega, Nat.factorial_succ,
              Nat.factorial_succ]
    _ = n.factorial * A n := by unfold A; ring

theorem factorial_double (n : ℕ) : (2 * n).factorial = n.factorial ^ 2 * B n := by
  have h := Nat.add_choose_mul_factorial_mul_factorial n n
  calc
    (2 * n).factorial = B n * n.factorial * n.factorial := by
      simpa [B, two_mul] using h.symm
    _ = n.factorial ^ 2 * B n := by ring

/-- Cancelling the common factorial square is essential, not an implication only. -/
theorem good3_iff_binomial (n : ℕ) : Good3 n ↔ A n ^ 2 ∣ B n := by
  unfold Good3
  rw [factorial_add_three, factorial_double, mul_pow]
  constructor
  · rintro ⟨k, hk⟩
    refine ⟨k, ?_⟩
    have hpos : 0 < n.factorial ^ 2 := pow_pos (Nat.factorial_pos n) 2
    have heq : n.factorial ^ 2 * B n = n.factorial ^ 2 * (A n ^ 2 * k) := by
      simpa only [mul_assoc] using hk
    exact Nat.eq_of_mul_eq_mul_left hpos heq
  · rintro ⟨k, hk⟩
    refine ⟨k, ?_⟩
    rw [hk]
    ring

theorem good2_of_good3 {n : ℕ} (h : Good3 n) : Good2 n := by
  have hd : (n + 2).factorial ^ 2 ∣ (n + 3).factorial ^ 2 := by
    refine ⟨(n + 3) ^ 2, ?_⟩
    rw [show n + 3 = (n + 2) + 1 by omega, Nat.factorial_succ]
    ring
  exact hd.trans h

theorem k2_of_k3 (h : K3) : Set.Infinite {n : ℕ | Good2 n} := by
  exact h.mono (fun _ hn => good2_of_good3 hn)

/-- Polynomial evaluation respects ordinary remainder congruence. -/
theorem f_mod (t m : ℕ) : f t % m = f (t % m) % m := by
  simp [f, Nat.add_mod, Nat.mul_mod, Nat.pow_mod]

theorem f_mod_eq_of_mod_eq {t u m : ℕ} (h : t % m = u % m) :
    f t % m = f u % m := by
  rw [f_mod t m, f_mod u m, h]

theorem progression_mod {Q t₀ v m : ℕ} (h : m ∣ Q) :
    (t₀ + Q * v) % m = t₀ % m := by
  simp [Nat.add_mod, Nat.mul_mod, Nat.mod_eq_zero_of_dvd h]

theorem F_mod {Q t₀ v m : ℕ} (h : m ∣ Q) :
    F Q t₀ v % m = f t₀ % m :=
  f_mod_eq_of_mod_eq (progression_mod h)

end Erdos727
