import Erdos727

-- These commands have NOT been executed in the preparation environment.
-- Inspect theorem TYPES as well as axiom lists: explicit unproved hypotheses
-- are not displayed as axiom dependencies.

#check Erdos727.K3
#print Erdos727.RequiredEstimates
#print Erdos727.k3_from_required_estimates

#print axioms Erdos727.good3_iff_binomial
#print axioms Erdos727.good3_iff_carries
#print axioms Erdos727.bad_prime_counts
#print axioms Erdos727.CRTCertificate.progression_target
#print axioms Erdos727.good3_805440
#print axioms Erdos727.k3_of_dyadicDensity
#print axioms Erdos727.k3_from_required_estimates
