# Erdős 727, k = 3 — review and partial Lean development

## Status: not a full formalization

**The mathematical audit found no fatal gap in the supplied argument.** It supports the manuscript as a candidate unconditional proof using its stated classical prime-number theorem in fixed arithmetic progressions. This is not expert peer review or formal certification.

**The Lean code is partial and has not been compiled or kernel-checked.** In particular, there is no unconditional Lean theorem proving `Erdos727.K3`. A complete formalization was requested, but was not completed in this delivery. The reasons are concrete: the analytic argument has not been encoded and proved, and there was no working Lean/Lake installation in the preparation environment. Network attempts to obtain the toolchain failed. Do not interpret “uncompiled” as meaning that only compilation remains; substantial mathematical formalization remains as well.

The code intentionally keeps the missing estimates as visible hypotheses rather than declaring them as axioms or silently replacing the theorem with a weaker claim. Absence of textual `sorry` is not evidence that the unconditional problem has been formalized. It is necessary to inspect theorem types as well as axiom lists.

## Contents

| File | Contents | Status |
|---|---|---|
| `SOURCE.md` | Unmodified supplied proof | Source material |
| `VALIDATION.md` | Section-by-section mathematical review, exact findings, and limitations | Informal audit |
| `checks.py` | Independent exact arithmetic audit, including CRT construction and parameter scan | Executed successfully |
| `attachment_checks.py` | Python code extracted from the attachment | Executed successfully |
| `checks_output.json` | Full independent results, exact Q and t0, residues, valuation certificate | Generated from executed audit |
| `Erdos727/Algebra.lean` | Polynomial identities, factorial cancellation, monotonicity, modular invariance, k=2 implication | Uncompiled proof draft |
| `Erdos727/Carries.lean` | Kummer specialization, primewise divisibility criterion, elementary carry lemmas | Uncompiled proof draft |
| `Erdos727/FiniteResidues.lean` | Rational coordinate identities, residue classes and counts, finite boundary checks | Uncompiled proof draft |
| `Erdos727/SmallPrimeCertificates.lean` | Concrete CRT data, local polynomial congruences, prescribed digit certificates | Uncompiled proof draft |
| `Erdos727/FiniteExample.lean` | A valuation-based proof draft for the actual example n=805440 | Uncompiled proof draft |
| `Erdos727/Counting.lean` | Explicit epsilon budgets and the conditional counting-to-infinitude implication | Uncompiled, conditional proof draft |
| `Erdos727/Obligations.lean` | Actual exceptional sets and the exact unproved inputs | Definitions and conditional theorem only |
| `Erdos727.lean` | Project entry point | Not compiled |
| `AuditAxioms.lean` | Theorem-type and dependency inspection commands | Not executed |
| `verification_status.json` | Machine-readable preparation status | Records that Lean was not checked |

All source indices are zero-based in Lean. Lean index 2 is the manuscript's third, specially favorable factor.

## What was actually checked

The original Python code and the independent audit agree on the example `f(61) = 805440`, its complete valuation certificate, and the count of **1612** successful parameters among `t = 1, ..., 10000`.

The independent audit also verifies the three factorizations of `f+j`, all rational coordinate identities, all derivative constants, all 15 pairwise determinants, the large-prime residue images and bad prime classes, the Hensel roots and CRT congruences, the numerical rational budgets, and the elementary Taylor-series comparisons used in the manuscript.

The computed CRT modulus has **436 digits**. The JSON output includes its entire exact value, the representative `t0`, and the six local lifting certificates. These integers are also embedded in `SmallPrimeCertificates.lean`. Their Python verification is not a Lean certificate until the corresponding Lean proof terms are actually checked.

Run the exact arithmetic checks with:

```sh
python3 attachment_checks.py
python3 checks.py
```

These scripts use only Python's standard library. Neither script proves infinitude.

## Exact distinction between the target and the conditional result

The unconditional target is:

```lean
def K3 : Prop := Set.Infinite {n : ℕ | Good3 n}
```

where `Good3 n` means `(Nat.factorial (n + 3)) ^ 2 ∣ Nat.factorial (2 * n)`.

The development provides a proof draft of the implication:

```lean
theorem k3_from_required_estimates {Q t₀ : ℕ}
    (h : RequiredEstimates Q t₀) : K3
```

**No value of `RequiredEstimates Q t₀` is provided.** Its fields require a positive modulus, failure coverage, and five eventual exceptional-set bounds. This is not equivalent to an unconditional theorem declaration. The conditional result is included because it formalizes the final assembly and fixes the exact proof obligations for the missing analytic work.

## Remaining formalization work

The outstanding work is organized by the actual source sections, not a generic “apply analytic number theory” placeholder.

1. **Progression safety and failure coverage (§§3–5, 10, 12).** Derive all small-prime valuation inequalities from the local congruences; prove that a prime above 1000 occurs in at most one linear form; combine square-factor exclusions, the first carry, and the prime-range partition into the coverage field. The draft local CRT congruences are not the whole coverage proof.
2. **Repeated factors and prime harmonic estimates (§§5–7).** Prove residue-class counts, the square-divisor union estimate, fixed-modulus harmonic prime asymptotics, and the weighted limit with its lower-endpoint control. A published classical theorem is not automatically a usable Lean import; no audited Lean proof of the required fixed-modulus analytic input has been imported here.
3. **Uniform medium-prime distribution (§§8–9).** Prove the quadratic exponential-sum bound with arbitrary real linear coefficient, derive uniform cancellation in the moving prime bands, pass to boxes using fixed finite approximations, and sum uniform errors over primes.
4. **Boundary and large-prime estimates (§§10–11).** Combine the finite residue tables with uniform control of the correction term, the special negative correction for the third factor, harmonic prime sums in fixed residue classes, and endpoint bounds.
5. **Final integration and stronger counting consequence.** Construct `RequiredEstimates` for the concrete progression, compile all files, inspect the unconditional theorem type and its axiom dependencies, and formalize the lower bound of order `sqrt Z` if the stronger theorem is to be included.

These obligations are mathematically argued in the attachment and reviewed in `VALIDATION.md`; they are not proved by the Lean source in this package.

## Reproducible Lean setup and checks

The project pins mathlib to revision:

```text
29ea5de9cb981cb62dfa7979aaff0851f50c603a
```

This is a revision referenced by the official API documentation examined during drafting. The project's compatibility with it has not been tested. No guessed `lean-toolchain` file is shipped: `setup_and_check.sh` fetches the matching toolchain identifier directly from the pinned dependency revision.

With `git`, an existing `elan`/`lake` installation, and working network access:

```sh
./setup_and_check.sh
```

The script obtains the exact toolchain file, resolves the dependency, fetches mathlib's cache, attempts to build the project, and runs the commands in `AuditAxioms.lean`. On a previously prepared installation:

```sh
./check_lean.sh
```

**Neither command was successfully run during preparation.** Compilation errors, API mismatches, or resource limits may need repair. The scripts have normal shell error handling; they do not announce success after a failed Lean command.

Even a successful build of this partial project would verify only its declared results. The conditional infinitude theorem would remain conditional until its explicit hypotheses are supplied. `AuditAxioms.lean` therefore prints `RequiredEstimates` and the theorem type, not only a list of axioms.

## Reference APIs used in drafting

The main existing mathlib results consulted were:

```text
Nat.add_choose_mul_factorial_mul_factorial
Nat.factorization_choose'
Nat.factorization_prime_le_iff_dvd
Nat.factorization_mul
Nat.Prime.factorization_pow
Nat.Prime.pow_dvd_iff_le_factorization
Nat.Prime.dvd_iff_one_le_factorization
Finset.card_filter_add_card_filter_not
```

The classical analytic input was cross-checked against NIST DLMF §27.12, especially equation 27.12.8. The public Formal Conjectures file for Erdős 727 was used only to check the target statement; its retrieved theorem placeholders were not treated as proofs.

## Interpretation

The completed deliverables are a mathematical review and reproducible finite arithmetic audits. The Lean files are substantive but uncompiled partial proof drafts. This package must not be described as a complete, verified Lean solution of Erdős 727 for k=3.
